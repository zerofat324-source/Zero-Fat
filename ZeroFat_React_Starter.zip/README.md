# Zero Fat – متابعة التغذية أونلاين | Online Nutrition Tracking

![Logo](public/logo.svg)

## 🇸🇦 نبذة
Zero Fat منصة احترافية لمتابعة التغذية بين الأخصائيين والعملاء. توفر خطط غذائية، متابعة التقدم، تواصل فوري، ومكتبة وصفات وفيديوهات.

## 🇺🇸 Overview
Zero Fat is a professional platform to connect nutritionists with clients with plans, progress tracking, chat, and a recipe/video library.

---

## 🎨 Brand Colors
- Primary Purple: `#6D28D9`
- Secondary Green: `#10B981`
- Dark BG: `#121826`
- White: `#FFFFFF`

---

## ⚙️ Run Locally
```bash
npm install
npm run dev
```
Then open the URL shown in terminal (usually http://localhost:5173).

---

## 🚀 Deploy (GitHub Pages / Netlify / Vercel)
- GitHub Pages: enable Pages and set source to `gh-pages` after running:
```bash
npm run deploy
```
- Netlify/Vercel: import the repo and select `npm run build` as build command, `dist` as output.

---

## 📱 Future (Web + Mobile)
- تحويل لاحقًا لتطبيق موبايل عبر React Native أو Ionic أو PWA.
- إضافة بوستات/فيديوهات/ريڤيوز ولوحة مالك واحد + عدة أخصائيين + آلاف العملاء.
