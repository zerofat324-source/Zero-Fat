import React, { useState, useEffect } from 'react';
const StyleInjector = () => {
  useEffect(() => {
    const tailwindScript = document.createElement('script');
    tailwindScript.src = 'https://cdn.tailwindcss.com';
    document.head.appendChild(tailwindScript);
    const style = document.createElement('style');
    style.innerHTML = `
      @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap');
      body { font-family: 'Cairo', sans-serif; direction: rtl; }
      .dark body { background-color: #121826; color: #e2e8f0; }
      .btn-primary { background:#6D28D9; color:white; font-weight:600; border-radius:0.5rem; padding:0.5rem 1rem }
      .btn-secondary { background:#10B981; color:white; font-weight:600; border-radius:9999px; padding:0.75rem 1.25rem }
      .section-title { font-size:2rem; font-weight:800; margin-bottom:1rem }
      .section-subtitle { color:#64748b; margin-bottom:2rem }
      .card { background:white; border-radius:0.75rem; box-shadow: 0 10px 25px rgba(0,0,0,.08); transition:transform .2s, box-shadow .2s }
      .card:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(0,0,0,.12) }
      .rtl-direction { direction: rtl; }
      .ltr-direction { direction: ltr; }
    `;
    document.head.appendChild(style);
    return () => {
      const existingScript = document.querySelector(`script[src="${tailwindScript.src}"]`);
      if (existingScript) document.head.removeChild(existingScript);
      document.head.removeChild(style);
    };
  }, []);
  return null;
};
const translations = {
  ar: {navHome:'الرئيسية',navFeatures:'المميزات',navPricing:'الأسعار',navLogin:'تسجيل الدخول',navDashboard:'لوحة التحكم',language:'English',heroTitle:'Zero Fat: طريقك لحياة صحية',heroSubtitle:'منصة ذكية تجمع أخصائيي التغذية بالعملاء لتحقيق أهدافهم الصحية بسهولة ومتابعة مستمرة.',heroCta:'ابدأ الآن مجاناً',featuresTitle:'لماذا تختار Zero Fat؟',featuresSubtitle:'أدوات متكاملة لإدارة نظامك الغذائي وتحقيق أفضل النتائج.',feature1Title:'لوحة العميل',feature1Desc:'خطط الوجبات، متابعة التقدم، إشعارات ذكية.',feature2Title:'لوحة الأخصائي',feature2Desc:'إدارة العملاء وتعديل الخطط ورفع محتوى.',feature3Title:'مكتبة صحية',feature3Desc:'وصفات صحية وفيديوهات تعليمية قصيرة.',pricingTitle:'خطط اشتراك مرنة',pricingSubtitle:'اختر الخطة المناسبة',planBasic:'الأساسية',planPro:'الاحترافية',planBusiness:'للأعمال',priceBasic:'مجاناً',pricePro:'$15',priceBusiness:'$40',perMonth:'/ شهرياً',featurePlan1:'متابعة الأهداف الأساسية',featurePlan2:'خطة وجبات أسبوعية',featurePlan3:'دعم عبر البريد',featurePlan4:'كل مميزات الأساسية +',featurePlan5:'خطط وجبات مخصصة',featurePlan6:'متابعة بالصور والقياسات',featurePlan7:'دعم مباشر',featurePlan8:'كل مميزات الاحترافية +',featurePlan9:'إدارة حتى 50 عميل',featurePlan10:'مكتبة وصفات خاصة',featurePlan11:'علامة تجارية خاصة',choosePlan:'اختر الخطة',footerRights:'جميع الحقوق محفوظة © Zero Fat',loginTitle:'مرحباً بعودتك!',loginSubtitle:'سجل الدخول للمتابعة',emailLabel:'البريد الإلكتروني',passwordLabel:'كلمة المرور',loginButton:'تسجيل الدخول',orSignup:'أو',signupButton:'إنشاء حساب جديد'},
  en: {navHome:'Home',navFeatures:'Features',navPricing:'Pricing',navLogin:'Login',navDashboard:'Dashboard',language:'العربية',heroTitle:'Zero Fat: Your Path to a Healthy Life',heroSubtitle:'A smart platform connecting nutritionists with clients with easy, continuous tracking.',heroCta:'Get Started for Free',featuresTitle:'Why Zero Fat?',featuresSubtitle:'Integrated tools to manage your diet.',feature1Title:'Client Dashboard',feature1Desc:'Meal plans, progress, reminders.',feature2Title:'Specialist Dashboard',feature2Desc:'Manage clients and content.',feature3Title:'Health Library',feature3Desc:'Recipes and short videos.',pricingTitle:'Flexible Plans',pricingSubtitle:'Pick what fits you.',planBasic:'Basic',planPro:'Pro',planBusiness:'Business',priceBasic:'Free',pricePro:'$15',priceBusiness:'$40',perMonth:'/ month',featurePlan1:'Basic goal tracking',featurePlan2:'Weekly meal plan',featurePlan3:'Email support',featurePlan4:'All Basic +',featurePlan5:'Custom plans',featurePlan6:'Photo & measurements tracking',featurePlan7:'Direct support',featurePlan8:'All Pro +',featurePlan9:'Manage up to 50 clients',featurePlan10:'Private recipe library',featurePlan11:'Private branding',choosePlan:'Choose Plan',footerRights:'All rights reserved © Zero Fat',loginTitle:'Welcome Back!',loginSubtitle:'Log in to continue',emailLabel:'Email',passwordLabel:'Password',loginButton:'Login',orSignup:'or',signupButton:'Create a new account'}
};
const Logo = () => (<div className="flex items-center gap-2"><img src="/logo.svg" alt="Zero Fat" className="h-10 w-auto" /><span className="text-2xl font-bold" style={{color:'#6D28D9'}}>ZeroFat</span></div>);
const Header = ({ lang, setLang, theme, setTheme, t, setModalOpen }) => {
  const [isMenuOpen, setMenuOpen] = useState(false);
  const toggleLanguage = () => { const newLang = lang === 'ar' ? 'en' : 'ar'; setLang(newLang); document.body.dir = newLang === 'ar' ? 'rtl' : 'ltr'; };
  const toggleTheme = () => { const newTheme = theme === 'light' ? 'dark' : 'light'; setTheme(newTheme); document.documentElement.classList.toggle('dark', newTheme === 'dark'); };
  return (<header className="bg-white/80 sticky top-0 z-40 shadow-md">
    <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
      <Logo />
      <div className="hidden md:flex items-center gap-8">
        <a href="#home" className="text-gray-600 hover:text-purple-600">{t.navHome}</a>
        <a href="#features" className="text-gray-600 hover:text-purple-600">{t.navFeatures}</a>
        <a href="#pricing" className="text-gray-600 hover:text-purple-600">{t.navPricing}</a>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-gray-100" aria-label="toggle theme">🌓</button>
        <button onClick={toggleLanguage} className="font-semibold hover:text-purple-600">{t.language}</button>
        <button onClick={()=>setModalOpen(true)} className="btn-primary hidden sm:block">{t.navLogin}</button>
        <button onClick={()=>setMenuOpen(!isMenuOpen)} className="md:hidden p-2 rounded-md hover:bg-gray-100">☰</button>
      </div>
    </nav>
    {isMenuOpen && (<div className="md:hidden bg-white shadow-lg">
      <a href="#home" className="block py-3 px-6" onClick={()=>setMenuOpen(false)}>{t.navHome}</a>
      <a href="#features" className="block py-3 px-6" onClick={()=>setMenuOpen(false)}>{t.navFeatures}</a>
      <a href="#pricing" className="block py-3 px-6" onClick={()=>setMenuOpen(false)}>{t.navPricing}</a>
      <div className="border-t my-2"></div>
      <button onClick={()=>{setModalOpen(true); setMenuOpen(false);}} className="w-full text-start py-3 px-6 text-purple-600 font-bold">{t.navLogin}</button>
    </div>)}
  </header>);
};
const HeroSection = ({ t }) => (<section id="home" className="py-20 bg-gray-50">
  <div className="container mx-auto px-6 text-center">
    <h1 className="text-4xl md:text-6xl font-extrabold text-gray-800 leading-tight">
      <span style={{color:'#10B981'}}>{t.heroTitle.split(':')[0]}:</span> {t.heroTitle.split(':')[1]}
    </h1>
    <p className="mt-4 text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">{t.heroSubtitle}</p>
    <a href="#pricing" className="mt-8 inline-block btn-secondary text-lg">{t.heroCta}</a>
  </div>
</section>);
const FeatureCard = ({ icon, title, desc }) => (<div className="card text-center p-8">
  <div className="mx-auto mb-4 rounded-full h-16 w-16 flex items-center justify-center" style={{background:'#10B98122'}}><span className="text-2xl">{icon}</span></div>
  <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
  <p className="text-gray-600">{desc}</p>
</div>);
const FeaturesSection = ({ t }) => (<section id="features" className="py-20">
  <div className="container mx-auto px-6">
    <h2 className="section-title text-center">{t.featuresTitle}</h2>
    <p className="section-subtitle text-center">{t.featuresSubtitle}</p>
    <div className="grid md:grid-cols-3 gap-8">
      <FeatureCard title={t.feature1Title} desc={t.feature1Desc} icon={"📊"} />
      <FeatureCard title={t.feature2Title} desc={t.feature2Desc} icon={"🧑‍⚕️"} />
      <FeatureCard title={t.feature3Title} desc={t.feature3Desc} icon={"📚"} />
    </div>
  </div>
</section>);
const PricingCard = ({ t, plan, price, per, features, primary=false }) => (<div className={`card p-8 border-2 ${primary ? 'border-purple-500' : 'border-transparent'} ${primary ? 'scale-105' : ''}`}>
  <h3 className="text-2xl font-bold text-center text-gray-800">{plan}</h3>
  <p className="text-center my-4"><span className="text-4xl font-extrabold" style={{color:'#10B981'}}>{price}</span>{per && <span className="text-gray-500">{per}</span>}</p>
  <ul className="space-y-3 my-6">{features.map((f, i)=>(<li key={i} className="flex items-start"><span className="mr-2 mt-1">✅</span><span className="text-gray-600">{f}</span></li>))}</ul>
  <button className={`w-full py-3 rounded-lg font-semibold shadow-lg ${primary ? 'btn-primary' : ''}`}>{t.choosePlan}</button>
</div>);
const PricingSection = ({ t }) => (<section id="pricing" className="py-20 bg-gray-50">
  <div className="container mx-auto px-6">
    <h2 className="section-title text-center">{t.pricingTitle}</h2>
    <p className="section-subtitle text-center">{t.pricingSubtitle}</p>
    <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto items-center">
      <PricingCard t={t} plan={t.planBasic} price={t.priceBasic} features={[t.featurePlan1, t.featurePlan2, t.featurePlan3]} />
      <PricingCard t={t} plan={t.planPro} price={t.pricePro} per={t.perMonth} features={[t.featurePlan4, t.featurePlan5, t.featurePlan6, t.featurePlan7]} primary />
      <PricingCard t={t} plan={t.planBusiness} price={t.priceBusiness} per={t.perMonth} features={[t.featurePlan8, t.featurePlan9, t.featurePlan10, t.featurePlan11]} />
    </div>
  </div>
</section>);
const Footer = ({ t }) => (<footer className="bg-gray-900 text-white py-8">
  <div className="container mx-auto px-6 text-center">
    <div className="flex justify-center"><Logo /></div>
    <p className="mt-4 text-gray-400">{new Date().getFullYear()} {t.footerRights}</p>
  </div>
</footer>);
const LoginModal = ({ t, isOpen, setModalOpen }) => {
  if (!isOpen) return null;
  const handleSubmit = (e) => { e.preventDefault(); setModalOpen(false); };
  return (<div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setModalOpen(false)}>
    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8" onClick={e=>e.stopPropagation()}>
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-800">{t.loginTitle}</h2>
        <p className="text-gray-500 mt-1">{t.loginSubtitle}</p>
      </div>
      <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
        <div>
          <label htmlFor="email" className="text-sm font-medium text-gray-700 block mb-2 text-start">{t.emailLabel}</label>
          <input type="email" id="email" required className="w-full px-4 py-3 bg-gray-100 rounded-lg focus:ring-2 focus:ring-purple-500" />
        </div>
        <div>
          <label htmlFor="password" className="text-sm font-medium text-gray-700 block mb-2 text-start">{t.passwordLabel}</label>
          <input type="password" id="password" required className="w-full px-4 py-3 bg-gray-100 rounded-lg focus:ring-2 focus:ring-purple-500" />
        </div>
        <button type="submit" className="w-full btn-primary py-3 text-lg">{t.loginButton}</button>
        <div className="flex items-center justify-center gap-2">
          <hr className="w-full border-gray-300" /><span className="text-gray-500 text-sm">{t.orSignup}</span><hr className="w-full border-gray-300" />
        </div>
        <button type="button" className="w-full btn-secondary py-3 text-lg">{t.signupButton}</button>
      </form>
    </div>
  </div>);
};
export default function App() {
  const [lang, setLang] = useState('ar');
  const [theme, setTheme] = useState('light');
  const [isModalOpen, setModalOpen] = useState(false);
  useEffect(() => { document.documentElement.lang = lang; document.body.dir = lang === 'ar' ? 'rtl' : 'ltr'; document.documentElement.classList.toggle('dark', theme === 'dark'); }, [lang, theme]);
  const t = translations[lang];
  return (<>
    <StyleInjector />
    <div className={`${lang === 'ar' ? 'rtl-direction' : 'ltr-direction'}`}>
      <Header lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} t={t} setModalOpen={setModalOpen} />
      <main><HeroSection t={t} /><FeaturesSection t={t} /><PricingSection t={t} /></main>
      <Footer t={t} />
      <LoginModal t={t} isOpen={isModalOpen} setModalOpen={setModalOpen} />
    </div>
  </>);
}
